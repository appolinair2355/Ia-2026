import { Link, useLocation } from "wouter";
import { Settings, LogOut, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

export function Navigation() {
  const [location] = useLocation();
  const isAdmin = location.startsWith("/admin");

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 px-6 py-4 flex justify-between items-center bg-background/50 backdrop-blur-md border-b border-white/5">
      <Link href="/" className="flex items-center gap-2 group cursor-pointer">
        <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center text-white font-bold text-xl shadow-lg shadow-primary/20 group-hover:scale-105 transition-transform">
          K
        </div>
        <span className="font-display font-bold text-lg tracking-tight text-white/90 group-hover:text-white transition-colors">
          Kousossou AI
        </span>
      </Link>

      <div className="flex items-center gap-4">
        {isAdmin ? (
          <div className="flex items-center gap-2">
            <Link href="/">
              <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-white gap-2">
                <ArrowLeft className="w-4 h-4" />
                Retour au Chat
              </Button>
            </Link>
            <Button 
              variant="destructive" 
              size="sm" 
              className="gap-2 shadow-lg shadow-destructive/20"
              onClick={() => {
                sessionStorage.removeItem("kousossou_auth");
                window.location.href = "/";
              }}
            >
              <LogOut className="w-4 h-4" />
              <span className="hidden sm:inline">Déconnexion</span>
            </Button>
          </div>
        ) : (
          <Link href="/admin">
            <Button variant="outline" size="sm" className="bg-white/5 border-white/10 hover:bg-white/10 hover:border-primary/50 text-white gap-2 transition-all hover:shadow-lg hover:shadow-primary/10">
              <Settings className="w-4 h-4" />
              <span className="hidden sm:inline">Administration</span>
            </Button>
          </Link>
        )}
      </div>
    </nav>
  );
}
