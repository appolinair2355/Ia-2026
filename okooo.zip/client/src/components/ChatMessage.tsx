import { motion } from "framer-motion";
import { User, Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";

interface ChatMessageProps {
  role: "user" | "ai";
  content: string;
}

export function ChatMessage({ role, content }: ChatMessageProps) {
  const isAi = role === "ai";

  return (
    <motion.div
      initial={{ opacity: 0, y: 10, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ duration: 0.3 }}
      className={cn(
        "flex gap-4 w-full max-w-3xl mx-auto mb-6",
        isAi ? "flex-row" : "flex-row-reverse"
      )}
    >
      <div 
        className={cn(
          "flex-shrink-0 w-10 h-10 rounded-xl flex items-center justify-center shadow-lg",
          isAi 
            ? "bg-gradient-to-br from-primary to-accent text-white shadow-primary/20" 
            : "bg-muted text-muted-foreground"
        )}
      >
        {isAi ? <Sparkles className="w-5 h-5" /> : <User className="w-5 h-5" />}
      </div>

      <div
        className={cn(
          "px-5 py-3.5 rounded-2xl text-base leading-relaxed max-w-[85%] shadow-sm",
          isAi
            ? "bg-card border border-white/5 text-card-foreground rounded-tl-none"
            : "bg-primary text-primary-foreground rounded-tr-none"
        )}
      >
        {content}
      </div>
    </motion.div>
  );
}
