import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import type { InsertCategory, InsertUnanswered, Category, Knowledge, UnansweredQuestion } from "@shared/schema";
import { z } from "zod";

// ==========================================
// CHAT
// ==========================================

export function useAskQuestion() {
  return useMutation({
    mutationFn: async (question: string) => {
      const validated = api.chat.ask.input.parse({ question });
      const res = await fetch(api.chat.ask.path, {
        method: api.chat.ask.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
      });
      if (!res.ok) throw new Error("Erreur lors de la communication avec l'IA");
      const data = await res.json();
      return {
        answer: data.answer,
        found: data.found,
        confidence: data.confidence
      };
    },
  });
}

// ==========================================
// ADMIN AUTH
// ==========================================

export function useAdminLogin() {
  return useMutation({
    mutationFn: async (password: string) => {
      // Direct success for any password in "no-auth" mode
      return { success: true };
    },
  });
}

// ==========================================
// CATEGORIES
// ==========================================

export function useCategories() {
  return useQuery({
    queryKey: [api.categories.list.path],
    queryFn: async () => {
      const password = sessionStorage.getItem("kousossou_auth") || "";
      const url = `${api.categories.list.path}?password=${encodeURIComponent(password)}`;
      const res = await fetch(url);
      if (!res.ok) throw new Error("Impossible de charger les catégories");
      return api.categories.list.responses[200].parse(await res.json());
    },
  });
}

export function useCreateCategory() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: InsertCategory) => {
      const validated = api.categories.create.input.parse(data);
      const password = sessionStorage.getItem("kousossou_auth") || "";
      const url = `${api.categories.create.path}?password=${encodeURIComponent(password)}`;
      const res = await fetch(url, {
        method: api.categories.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
      });
      if (!res.ok) {
        if (res.status === 400) throw new Error("Données invalides");
        throw new Error("Impossible de créer la catégorie");
      }
      return api.categories.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.categories.list.path] });
    },
  });
}

export function useDeleteCategory() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (id: number) => {
      const password = sessionStorage.getItem("kousossou_auth") || "";
      const url = `${buildUrl(api.categories.delete.path, { id })}?password=${encodeURIComponent(password)}`;
      const res = await fetch(url, { method: api.categories.delete.method });
      if (!res.ok) throw new Error("Impossible de supprimer la catégorie");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.categories.list.path] });
    },
  });
}

// ==========================================
// KNOWLEDGE BASE (IMPORT)
// ==========================================

export function useImportKnowledge() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: { categoryId: number; content: string; password?: string }) => {
      const password = data.password || sessionStorage.getItem("kousossou_auth") || "";
      const validated = { 
        categoryId: data.categoryId, 
        content: data.content,
        password: password
      };
      
      const res = await fetch(`${api.knowledge.import.path}?password=${encodeURIComponent(password)}`, {
        method: api.knowledge.import.method,
        headers: { 
          "Content-Type": "application/json",
          "x-admin-password": password
        },
        body: JSON.stringify(validated),
      });
      
      if (!res.ok) {
        if (res.status === 401) throw new Error("Non autorisé : session expirée ou mot de passe incorrect");
        throw new Error("Échec de l'importation");
      }
      return api.knowledge.import.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.unanswered.list.path] });
    }
  });
}

// ==========================================
// UNANSWERED QUESTIONS
// ==========================================

export function useUnansweredQuestions() {
  return useQuery({
    queryKey: [api.unanswered.list.path],
    queryFn: async () => {
      const password = sessionStorage.getItem("kousossou_auth") || "";
      const url = `${api.unanswered.list.path}?password=${encodeURIComponent(password)}`;
      const res = await fetch(url);
      if (!res.ok) throw new Error("Impossible de charger les questions");
      return api.unanswered.list.responses[200].parse(await res.json());
    },
  });
}

export function useResolveQuestion() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: { id: number; answer: string; categoryId: number }) => {
      const validated = api.unanswered.resolve.input.parse(data);
      const password = sessionStorage.getItem("kousossou_auth") || "";
      const url = `${api.unanswered.resolve.path}?password=${encodeURIComponent(password)}`;

      const res = await fetch(url, {
        method: api.unanswered.resolve.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
      });
      if (!res.ok) throw new Error("Impossible de résoudre la question");
      return api.unanswered.resolve.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.unanswered.list.path] });
    },
  });
}
