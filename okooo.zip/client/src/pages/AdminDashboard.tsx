import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Navigation } from "@/components/Navigation";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useCategories, useCreateCategory, useDeleteCategory, useImportKnowledge, useUnansweredQuestions, useResolveQuestion } from "@/hooks/use-kousossou";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Trash2, Plus, Upload, CheckCircle2, MessageSquare, Tag, FileText } from "lucide-react";
import { motion } from "framer-motion";

export default function AdminDashboard() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  // Redirect if not auth (Disabled for now)
  useEffect(() => {
    // sessionStorage.setItem("kousossou_auth", "kouame");
  }, []);

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Navigation />
      
      <main className="max-w-6xl mx-auto pt-24 px-4 pb-12">
        <div className="mb-8">
          <h1 className="text-3xl font-display font-bold text-white mb-2">Tableau de Bord</h1>
          <p className="text-muted-foreground">Gérez les catégories, importez des connaissances et répondez aux questions.</p>
        </div>

        <Tabs defaultValue="categories" className="space-y-8">
          <TabsList className="bg-card/50 border border-white/5 p-1 h-auto rounded-xl inline-flex w-full md:w-auto">
            <TabsTrigger value="categories" className="py-2.5 px-6 rounded-lg data-[state=active]:bg-primary data-[state=active]:text-white">
              <Tag className="w-4 h-4 mr-2" /> Catégories
            </TabsTrigger>
            <TabsTrigger value="import" className="py-2.5 px-6 rounded-lg data-[state=active]:bg-primary data-[state=active]:text-white">
              <FileText className="w-4 h-4 mr-2" /> Importer
            </TabsTrigger>
            <TabsTrigger value="questions" className="py-2.5 px-6 rounded-lg data-[state=active]:bg-primary data-[state=active]:text-white">
              <MessageSquare className="w-4 h-4 mr-2" /> Questions Non Résolues
            </TabsTrigger>
          </TabsList>

          {/* ================= CATEGORIES TAB ================= */}
          <TabsContent value="categories" className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <CategoriesManager />
          </TabsContent>

          {/* ================= IMPORT TAB ================= */}
          <TabsContent value="import" className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <ImportManager />
          </TabsContent>

          {/* ================= QUESTIONS TAB ================= */}
          <TabsContent value="questions" className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <QuestionsManager />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}

function CategoriesManager() {
  const { data: categories, isLoading } = useCategories();
  const createMutation = useCreateCategory();
  const deleteMutation = useDeleteCategory();
  const { toast } = useToast();
  const [newCategory, setNewCategory] = useState("");

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCategory.trim()) return;
    try {
      await createMutation.mutateAsync({ name: newCategory });
      setNewCategory("");
      toast({ title: "Succès", description: "Catégorie créée avec succès" });
    } catch (err: any) {
      toast({ title: "Erreur", description: err.message, variant: "destructive" });
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm("Êtes-vous sûr de vouloir supprimer cette catégorie ?")) return;
    try {
      await deleteMutation.mutateAsync(id);
      toast({ title: "Succès", description: "Catégorie supprimée" });
    } catch (err: any) {
      toast({ title: "Erreur", description: err.message, variant: "destructive" });
    }
  };

  return (
    <div className="grid md:grid-cols-3 gap-6">
      {/* Create Form */}
      <Card className="md:col-span-1 h-fit glass-panel">
        <CardHeader>
          <CardTitle>Nouvelle Catégorie</CardTitle>
          <CardDescription>Ajoutez une catégorie pour organiser vos connaissances.</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleCreate} className="space-y-4">
            <Input 
              placeholder="Nom de la catégorie..." 
              value={newCategory}
              onChange={(e) => setNewCategory(e.target.value)}
              className="bg-background/50"
            />
            <Button type="submit" className="w-full bg-primary hover:bg-primary/90" disabled={createMutation.isPending}>
              {createMutation.isPending ? "Création..." : <><Plus className="w-4 h-4 mr-2" /> Créer</>}
            </Button>
          </form>
        </CardContent>
      </Card>

      {/* List */}
      <Card className="md:col-span-2 glass-panel">
        <CardHeader>
          <CardTitle>Liste des Catégories</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-8 text-muted-foreground">Chargement...</div>
          ) : categories?.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground border border-dashed border-white/10 rounded-lg">
              Aucune catégorie pour le moment.
            </div>
          ) : (
            <div className="grid gap-3">
              {categories?.map((cat) => (
                <div key={cat.id} className="flex items-center justify-between p-4 rounded-lg bg-background/30 border border-white/5 hover:border-white/10 transition-colors">
                  <span className="font-medium">{cat.name}</span>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="text-destructive hover:bg-destructive/10 hover:text-destructive"
                    onClick={() => handleDelete(cat.id)}
                    disabled={deleteMutation.isPending}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function ImportManager() {
  const { data: categories } = useCategories();
  const importMutation = useImportKnowledge();
  const { toast } = useToast();
  
  const [categoryId, setCategoryId] = useState<string>("");
  const [content, setContent] = useState("");

  const handleImport = async () => {
    if (!categoryId || !content.trim()) {
      toast({ title: "Erreur", description: "Veuillez sélectionner une catégorie et entrer du contenu", variant: "destructive" });
      return;
    }
    try {
      const lines = content.split('\n');
      let imported = 0;
      let duplicates = 0;

      for (const line of lines) {
        if (!line.trim()) continue;
        const [qPart, rest] = line.split('=');
        if (!qPart || !rest) continue;
        
        const [answer, alts, intention, ton] = rest.split('||').map(s => s.trim());
        
        if (qPart.trim() && answer) {
          const exists = await storage.checkKnowledgeExists(qPart.trim(), parseInt(categoryId));
          if (!exists) {
            await storage.addKnowledge({
              question: qPart.trim(),
              answer: answer,
              alternativeAnswers: alts || null,
              intention: intention || null,
              ton: ton || null,
              categoryId: parseInt(categoryId)
            });
            imported++;
          } else {
            duplicates++;
          }
        }
      }
      
      toast({ title: "Importation réussie", description: `${imported} questions importées, ${duplicates} doublons ignorés.` });
      setContent("");
    } catch (err: any) {
      toast({ title: "Erreur", description: err.message, variant: "destructive" });
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = (event) => {
      if (event.target?.result) {
        setContent(event.target.result as string);
      }
    };
    reader.readAsText(file);
  };

  return (
    <Card className="glass-panel">
      <CardHeader>
        <CardTitle>Importer des Connaissances</CardTitle>
        <CardDescription>
          Copiez-collez votre contenu ci-dessous ou importez un fichier .txt. <br />
          Format attendu: <code className="bg-black/30 px-1 rounded">Question = Réponse</code> (une par ligne)
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <label className="text-sm font-medium text-muted-foreground">Catégorie Cible</label>
            <Select value={categoryId} onValueChange={setCategoryId}>
              <SelectTrigger className="w-full bg-background/50">
                <SelectValue placeholder="Choisir une catégorie" />
              </SelectTrigger>
              <SelectContent>
                {categories?.map((cat) => (
                  <SelectItem key={cat.id} value={cat.id.toString()}>{cat.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-muted-foreground">Fichier Texte (Optionnel)</label>
            <Input type="file" accept=".txt" onChange={handleFileUpload} className="bg-background/50 cursor-pointer" />
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-sm font-medium text-muted-foreground">Contenu à importer</label>
          <Textarea 
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="Question 1 = Réponse 1&#10;Question 2 = Réponse 2"
            className="min-h-[200px] font-mono text-sm bg-background/50 leading-relaxed"
          />
        </div>

        <div className="flex justify-end">
          <Button onClick={handleImport} disabled={importMutation.isPending} className="bg-primary hover:bg-primary/90 text-white min-w-[150px]">
            {importMutation.isPending ? "Importation..." : <><Upload className="w-4 h-4 mr-2" /> Importer</>}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

function QuestionsManager() {
  const { data: questions, isLoading } = useUnansweredQuestions();
  const { data: categories } = useCategories();
  const resolveMutation = useResolveQuestion();
  const { toast } = useToast();
  
  const [selectedQuestion, setSelectedQuestion] = useState<{ id: number, text: string } | null>(null);
  const [answer, setAnswer] = useState("");
  const [categoryId, setCategoryId] = useState<string>("");

  const handleResolve = async () => {
    if (!selectedQuestion || !answer.trim() || !categoryId) {
      toast({ title: "Erreur", description: "Veuillez remplir tous les champs", variant: "destructive" });
      return;
    }
    try {
      await resolveMutation.mutateAsync({
        id: selectedQuestion.id,
        answer,
        categoryId: parseInt(categoryId)
      });
      toast({ title: "Succès", description: "Question résolue et ajoutée à la base de connaissances" });
      setSelectedQuestion(null);
      setAnswer("");
      setCategoryId("");
    } catch (err: any) {
      toast({ title: "Erreur", description: err.message, variant: "destructive" });
    }
  };

  return (
    <div className="grid lg:grid-cols-2 gap-8">
      {/* List */}
      <Card className="glass-panel overflow-hidden flex flex-col h-[600px]">
        <CardHeader>
          <CardTitle>Questions en attente</CardTitle>
          <CardDescription>Cliquez sur une question pour y répondre.</CardDescription>
        </CardHeader>
        <CardContent className="flex-1 overflow-y-auto p-0">
          {isLoading ? (
            <div className="p-8 text-center text-muted-foreground">Chargement...</div>
          ) : questions?.length === 0 ? (
            <div className="p-12 text-center flex flex-col items-center gap-4 text-muted-foreground">
              <CheckCircle2 className="w-12 h-12 text-primary/50" />
              <p>Toutes les questions ont été traitées !</p>
            </div>
          ) : (
            <div className="divide-y divide-white/5">
              {questions?.map((q) => (
                <button
                  key={q.id}
                  onClick={() => setSelectedQuestion({ id: q.id, text: (q as any).question })}
                  className={`w-full text-left p-4 transition-colors hover:bg-white/5 ${selectedQuestion?.id === q.id ? "bg-primary/10 border-l-4 border-primary" : ""}`}
                >
                  <p className="font-medium line-clamp-2">{(q as any).question}</p>
                  <p className="text-xs text-muted-foreground mt-2">
                    Posée le {new Date((q as any).askedAt || "").toLocaleDateString()}
                  </p>
                </button>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Editor */}
      <Card className="glass-panel h-fit">
        <CardHeader>
          <CardTitle>Répondre</CardTitle>
          <CardDescription>
            {selectedQuestion ? "Rédigez la réponse pour l'ajouter à la base." : "Sélectionnez une question à gauche."}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {selectedQuestion ? (
            <motion.div 
              initial={{ opacity: 0 }} animate={{ opacity: 1 }}
              className="space-y-6"
            >
              <div className="p-4 rounded-lg bg-background/50 border border-white/5">
                <span className="text-xs uppercase tracking-wider text-muted-foreground mb-1 block">Question</span>
                <p className="text-lg font-medium">{selectedQuestion.text}</p>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Catégorie</label>
                <Select value={categoryId} onValueChange={setCategoryId}>
                  <SelectTrigger className="bg-background/50">
                    <SelectValue placeholder="Choisir une catégorie" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories?.map((cat) => (
                      <SelectItem key={cat.id} value={cat.id.toString()}>{cat.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Réponse</label>
                <Textarea 
                  value={answer}
                  onChange={(e) => setAnswer(e.target.value)}
                  placeholder="Écrivez la réponse ici..."
                  className="min-h-[150px] bg-background/50 resize-none"
                />
              </div>

              <div className="flex justify-end gap-3 pt-4">
                <Button variant="ghost" onClick={() => setSelectedQuestion(null)}>Annuler</Button>
                <Button onClick={handleResolve} disabled={resolveMutation.isPending} className="bg-primary hover:bg-primary/90 text-white">
                  {resolveMutation.isPending ? "Enregistrement..." : "Valider et Ajouter"}
                </Button>
              </div>
            </motion.div>
          ) : (
            <div className="h-[300px] flex items-center justify-center text-muted-foreground bg-black/20 rounded-lg border border-dashed border-white/10">
              Sélectionnez une question pour commencer
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
