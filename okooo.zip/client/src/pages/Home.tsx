import { useState, useRef, useEffect } from "react";
import { Send, Sparkles } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Navigation } from "@/components/Navigation";
import { ChatMessage } from "@/components/ChatMessage";
import { useAskQuestion } from "@/hooks/use-kousossou";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

const PLACEHOLDERS = [
  "Que voulez-vous savoir ?",
  "Posez-moi une question sur Kousossou...",
  "Besoin d'aide ? Demandez-moi !",
  "Je suis là pour vous répondre."
];

interface Message {
  role: "user" | "ai";
  content: string;
}

export default function Home() {
  const [input, setInput] = useState("");
  const [placeholderIndex, setPlaceholderIndex] = useState(0);
  const [messages, setMessages] = useState<Message[]>([]);
  const scrollRef = useRef<HTMLDivElement>(null);
  const askMutation = useAskQuestion();

  // Placeholder rotation
  useEffect(() => {
    const interval = setInterval(() => {
      setPlaceholderIndex((prev) => (prev + 1) % PLACEHOLDERS.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  // Auto-scroll to bottom
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || askMutation.isPending) return;

    const question = input.trim();
    setInput("");
    
    // Add user message immediately
    setMessages(prev => [...prev, { role: "user", content: question }]);

    try {
      const response = await askMutation.mutateAsync(question);
      
      const aiResponse = response.answer;

      setMessages(prev => [...prev, { role: "ai", content: aiResponse }]);
    } catch (error) {
      setMessages(prev => [...prev, { role: "ai", content: "Désolé, une erreur est survenue lors de la communication avec le serveur." }]);
    }
  };

  return (
    <div className="min-h-screen bg-background flex flex-col font-sans selection:bg-primary/30 text-foreground">
      <Navigation />

      <main className="flex-1 flex flex-col w-full max-w-5xl mx-auto pt-24 px-4 pb-4">
        
        {messages.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center text-center space-y-8 animate-in fade-in duration-700">
            <div className="relative">
              <div className="absolute -inset-1 rounded-full bg-gradient-to-r from-primary to-accent blur-xl opacity-30 animate-pulse" />
              <div className="relative w-24 h-24 rounded-2xl bg-gradient-to-br from-primary to-accent flex items-center justify-center shadow-2xl shadow-primary/30">
                <Sparkles className="w-10 h-10 text-white" />
              </div>
            </div>
            
            <div className="space-y-4 max-w-lg">
              <h1 className="text-4xl md:text-5xl font-display font-bold bg-clip-text text-transparent bg-gradient-to-b from-white to-white/60">
                Bonjour, je suis <span className="text-primary">Kousossou</span>
              </h1>
              <p className="text-lg text-muted-foreground leading-relaxed">
                Votre assistant intelligent personnel. Posez-moi n'importe quelle question et je ferai de mon mieux pour vous aider.
              </p>
            </div>
          </div>
        ) : (
          <div className="flex-1 overflow-y-auto space-y-6 pb-24 scroll-smooth">
            {messages.map((msg, i) => (
              <ChatMessage key={i} role={msg.role} content={msg.content} />
            ))}
            {askMutation.isPending && (
              <div className="flex gap-4 w-full max-w-3xl mx-auto">
                 <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center shadow-lg shadow-primary/20 animate-pulse">
                    <Sparkles className="w-5 h-5 text-white" />
                 </div>
                 <div className="flex items-center gap-1.5 px-4 py-4">
                    <div className="w-2 h-2 rounded-full bg-primary/40 animate-bounce [animation-delay:-0.3s]" />
                    <div className="w-2 h-2 rounded-full bg-primary/40 animate-bounce [animation-delay:-0.15s]" />
                    <div className="w-2 h-2 rounded-full bg-primary/40 animate-bounce" />
                 </div>
              </div>
            )}
            <div ref={scrollRef} />
          </div>
        )}

        {/* Input Area */}
        <div className="fixed bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-background via-background to-transparent pt-12">
          <div className="max-w-3xl mx-auto relative">
            <form onSubmit={handleSubmit} className="relative group">
              <div className="absolute -inset-0.5 rounded-2xl bg-gradient-to-r from-primary/50 to-accent/50 opacity-0 group-focus-within:opacity-100 transition-opacity duration-300 blur" />
              <div className="relative flex items-center bg-card rounded-2xl border border-white/10 shadow-2xl overflow-hidden">
                <Input
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder={PLACEHOLDERS[placeholderIndex]}
                  className="flex-1 border-0 bg-transparent px-6 py-6 h-auto text-lg focus-visible:ring-0 placeholder:text-muted-foreground/50"
                  autoFocus
                />
                <div className="pr-3">
                  <Button 
                    type="submit" 
                    size="icon"
                    disabled={!input.trim() || askMutation.isPending}
                    className={
                      "w-12 h-12 rounded-xl transition-all duration-300 " + 
                      (input.trim() 
                        ? "bg-primary text-primary-foreground shadow-lg shadow-primary/25 hover:scale-105 hover:bg-primary/90" 
                        : "bg-muted text-muted-foreground/50 cursor-not-allowed")
                    }
                  >
                    <Send className="w-5 h-5" />
                  </Button>
                </div>
              </div>
            </form>
            <div className="text-center mt-3 flex flex-col items-center gap-2">
              <div className="flex flex-wrap justify-center gap-4">
                <Button variant="ghost" asChild size="sm" className="text-muted-foreground/40 hover:text-primary">
                  <a href="/kouii.zip" download="kouii.zip">kouii.zip</a>
                </Button>
                <Button variant="ghost" asChild size="sm" className="text-muted-foreground/40 hover:text-primary">
                  <a href="/hhh.zip" download="hhh.zip">hhh.zip</a>
                </Button>
                <Button variant="ghost" asChild size="sm" className="text-muted-foreground/40 hover:text-primary">
                  <a href="/kkk.zip" download="kkk.zip">kkk.zip</a>
                </Button>
              </div>
              <p className="text-xs text-muted-foreground/40 font-mono">
                Propulsé par Kousossou AI v1.0
              </p>
            </div>
          </div>
        </div>

      </main>
    </div>
  );
}
